ZORA Monetag Basic Website

Files:
- index.html
- style.css
- script.js

Monetag zone:
11982192

The page has:
- Basic ZORA interface
- Watch Ad button
- Ads Opened counter
- Counter saved in browser localStorage

Important:
The counter records ad-open attempts after the Monetag SDK function is started. It is not an official Monetag revenue/reporting counter.

For testing, use a local web server or your hosted HTTPS website. Opening index.html directly with file:// may prevent ad scripts from working correctly.

Do not change the Monetag SDK line unless Monetag gives you a different tag.
