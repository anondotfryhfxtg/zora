const button = document.getElementById("watchAd");
const countEl = document.getElementById("adCount");
const statusEl = document.getElementById("status");

let adCount = Number(localStorage.getItem("zora_ad_count") || 0);
countEl.textContent = adCount;

button.addEventListener("click", async () => {
  if (typeof window.show_11982192 !== "function") {
    statusEl.textContent = "Ad system is not ready. Please try again.";
    return;
  }

  button.disabled = true;
  statusEl.textContent = "Opening ad...";

  try {
    const result = window.show_11982192();

    // Count an ad when the Monetag ad request is successfully started.
    adCount += 1;
    localStorage.setItem("zora_ad_count", String(adCount));
    countEl.textContent = adCount;

    if (result && typeof result.then === "function") {
      await result;
    }

    statusEl.textContent = "Ad opened.";
  } catch (error) {
    statusEl.textContent = "Could not open the ad. Please try again.";
  } finally {
    setTimeout(() => {
      button.disabled = false;
      statusEl.textContent = "Ready";
    }, 1500);
  }
});
